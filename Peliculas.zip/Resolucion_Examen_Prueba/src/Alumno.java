
public class Alumno {

	String id;
	String nombre;
	int edad;
	String sexo;
	float p1;
	float p2;
	float promedio; 
	String carrera;
	
	public Alumno(String id, String nombre, int edad, String sexo, float p1, float p2, float promedio, String carrera) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
		this.p1 = p1;
		this.p2 = p2;
		this.promedio = promedio;
		this.carrera = carrera;
	}
	
	@Override
	public String toString() {
		return "Alumno [id=" + id + ", nombre=" + nombre + ", edad=" + edad + ", sexo=" + sexo + ", p1=" + p1 + ", p2="
				+ p2 + ", promedio=" + promedio + ", carrera=" + carrera + "]";
	}

	public Alumno() {
		super();
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public float getP1() {
		return p1;
	}
	public void setP1(float p1) {
		this.p1 = p1;
	}
	public float getP2() {
		return p2;
	}
	public void setP2(float p2) {
		this.p2 = p2;
	}
	public float getPromedio() {
		return promedio;
	}
	public void setPromedio(float promedio) {
		this.promedio = promedio;
	}
	public String getCarrera() {
		return carrera;
	}
	public void setCarrera(String carrera) {
		this.carrera = carrera;
	}
	
}
