import java.util.ArrayList;
import java.util.Scanner;

/*
 * Desarrollar un Programa POO, en base a las siguientes indicaciones:

Se tiene una clase alumno que tiene como atributos id, nombre, edad, sexo, p1, p2, promedio, carrera, se debe generar un menu de opciones para la gestion del programa.

Ingresar datos al arrayList.
Elabore un método que agregue a una lista auxiliar alumnos que solo tenga promedio mayores a 15, ese método debe retornar dicha lista para su impresion
Elabore un método que elimine todos alumnos de sexo masculino
Elabore un método que elimine todos alumnos que pertenezcan a una carrera en especifico, la carrera sera solicitada antes de la eliminacion.
Elabore un método que imprima porcentaje de aprobados en la PC1 y en la PC2. Considere la nota aprobatoria mayor a 15
Elabore un método que retorne la cantidad de alumnos cuyas notas se encuentre en un rango, los valores del rango son ingresados por telcado
*/

public class main {
	
	static Scanner leer = new Scanner(System.in);

	public static void main(String[] args) {
		
		ArrayList <Alumno> listaAlumno= new ArrayList <>();
		boolean salir = false;
		
		while (salir==false){
            System.out.println("-----------Menu--------");
            System.out.println("1. Ingresar datos");
            System.out.println("2. Retornar alumnos con promedio mayor a 15");
            System.out.println("3. Eliminar alumnos con sexo masculino");
            System.out.println("4. Eliminar una carrera en específico");
            System.out.println("5. Retornar porcentaje de aprobados en PC1 y PC2");
            System.out.println("6. Retornar alumnos con notas dentro de un rango específico");
            System.out.println("7. Imprimir datos");
            System.out.println("8. Salir");
            int op=leer.nextInt();
            
            switch(op) {
			 case 1:
				 Alumno alumno= nuevoAlumno();
				 listaAlumno.add(alumno);
				 break;
			 case 2:
				 ArrayList <Alumno> listaAuxiliar = crearListaPromedioMayor(listaAlumno);
				 System.out.println(listaAuxiliar);
				 break;
			 case 3:
				 listaAlumno = eliminarMasculino(listaAlumno);
				 break;
			 case 4:
				 listaAlumno = eliminarCarrera(listaAlumno);
				 break;				 
			 case 5: 	
				 imprimirAprobados(listaAlumno);
				 break;
			 case 6:
				 imprimirRango(listaAlumno);
				 break;
			 case 7:
				 System.out.println(listaAlumno); 
				 break;
			 case 8:
				 salir=true; 
				 break;
			 }

	}

}
	
	public static Alumno nuevoAlumno() {
		System.out.println("Ingrese su id");
		String id = leer.next();
		System.out.println("Ingrese su nombre");
		String nombre = leer.next();
		System.out.println("Ingrese su edad");
		int edad = leer.nextInt();
		System.out.println("Ingrese su sexo (Masculino o Femenino)");
		String sexo = leer.next();
		System.out.println("Ingrese su nota del parcial 1");
		float p1= leer.nextFloat();
		System.out.println("Ingrese su nota del parcial 2");
		float p2= leer.nextFloat();
		System.out.println("Ingrese su promedio");
		float promedio = leer.nextFloat();
		System.out.println("Ingrese su carrera");
		String carrera = leer.next();
		
		Alumno alumno = new Alumno (id, nombre, edad, sexo, p1, p2, promedio, carrera);
		return alumno;
	}
	
	public static ArrayList <Alumno>  crearListaPromedioMayor(ArrayList <Alumno>  listaAlumno) {
		
		ArrayList <Alumno> listaAuxiliar= new ArrayList <>();
		
		for (Alumno alumnoTurno: listaAlumno) {
			if (alumnoTurno.getPromedio()>15) {
				listaAuxiliar.add(alumnoTurno);
			}
		}
		
		return listaAuxiliar;
		
	}
	
	public static ArrayList <Alumno>  eliminarMasculino(ArrayList <Alumno>  listaAlumno) {
		
		for (int i =0; i<listaAlumno.size(); i++) {
			Alumno alumnoTurno = listaAlumno.get(i);
			if (alumnoTurno.getSexo().equals("Masculino")) {
				listaAlumno.remove(i);
                i--;
			}
		}
		
		return listaAlumno;
		
	}
	

	public static ArrayList <Alumno>  eliminarCarrera(ArrayList <Alumno>  listaAlumno) {
		
		System.out.println("Ingrese la carrera que desea eliminar");
		String carreraEliminar = leer.next();
		
		for (int i =0; i<listaAlumno.size(); i++) {
			Alumno alumnoTurno = listaAlumno.get(i);
			if (alumnoTurno.getCarrera().equals(carreraEliminar)) {
				listaAlumno.remove(i);
				i--;
			}
		}
		
		return listaAlumno;
		
	}
	
	public static void imprimirAprobados(ArrayList <Alumno>  listaAlumno) {
		
		float totalAlumnos = 0; 
		float totalAprobadosP1 = 0;
		float totalAprobadosP2 = 0;
		for (Alumno alumnoTurno: listaAlumno) {
			totalAlumnos++;
			
			if (alumnoTurno.getP1()>=15) {
				totalAprobadosP1++;			
			}
			
			if (alumnoTurno.getP2()>=15) {
				totalAprobadosP2++;			
			}
		}
		
		System.out.println("Porcentaje de alumnos aprobados en P1: "+((totalAprobadosP1/totalAlumnos)*100) +"%");
		System.out.println("Porcentaje de alumnos aprobados en P2: "+((totalAprobadosP2/totalAlumnos)*100) +"%");
		
	}
	
	public static void imprimirRango(ArrayList <Alumno>  listaAlumno) {
		
		int totalAlumnosRango = 0;
		
		System.out.println("Ingrese el valor menor del rango");
		float minimo = leer.nextFloat();
		System.out.println("Ingrese el valor mayor del rango");
		float maximo = leer.nextFloat();
		
		for (Alumno alumnoTurno: listaAlumno) {
			
			if ((alumnoTurno.getPromedio()>minimo) && (alumnoTurno.getPromedio()<maximo)) {
				totalAlumnosRango++;
			}
						
		}
		
		System.out.println("Numero total de alumnos con promedio dentro del rango: "+ totalAlumnosRango);
		
	}
	

	}
