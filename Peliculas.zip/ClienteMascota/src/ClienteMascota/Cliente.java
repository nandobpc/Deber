package ClienteMascota;

public class Cliente {
public String toString() {
	return "Cliente[cedula=" + cedula +", nombres=" + nombres + ", apellidos=" + apellidos + ", telefono=" + 
			telefono + ", mes de nacimiento " + mesdenacimiento +"]";
}
	String cedula;
	String nombres;
	String apellidos;
	String telefono;
	int mesdenacimiento;

public String getCedula() {
		return cedula;
	}



	public void setCedula(String cedula) {
		this.cedula = cedula;
	}



	public String getNombres() {
		return nombres;
	}



	public void setNombres(String nombres) {
		this.nombres = nombres;
	}



	public String getApellidos() {
		return apellidos;
	}



	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}



	public String getTelefono() {
		return telefono;
	}



	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}



	public int getMesdenacimiento() {
		return mesdenacimiento;
	}



	public void setMesdenacimiento(int mesdenacimiento) {
		this.mesdenacimiento = mesdenacimiento;
	}



public Cliente(String cedula2, String nombres, String apellidos, String telefono, int
		mesdenacimiento) {
			 this.cedula = cedula2;
			 this.nombres = nombres;
			 this.apellidos = apellidos;
			 this.telefono = telefono;
			 this.mesdenacimiento = mesdenacimiento;
			 }



public static void add(Cliente cliente) {
	
	
}
			}

