package ClienteMascota;

public class Mascota {
	public String toString() {
		return "Mascota fecha=" + fecha+ ", raza=" + raza +", color=" + color + ", tipo=" + tipo +"]";
	}
		String fecha;
		String raza;
		String color;
		String tipo;
		
		public String getFecha() {
			return fecha;
		}
		public void setFecha(String fecha) {
			this.fecha = fecha;
		}
		public void setraza(String raza) {
			 this.raza = raza;
		}
		public void setcolor(String color) {
			 this.color = color;
	}
		public void settipo(String tipo) {
			 this.tipo = tipo;
	}
			 
			
		public String getraza() {
			 return raza;
			 }
		public String getcolor() {
			 return color;
			 }
		public String gettipo() {
			 return tipo;
		}

	public Mascota( String raza, String color, String tipo ) {
				 this.raza = raza;
				 this.color = color;
				 this.tipo = tipo;
				 
				 }

	public static void add(Mascota mascota) {
		
		
	}
				}



