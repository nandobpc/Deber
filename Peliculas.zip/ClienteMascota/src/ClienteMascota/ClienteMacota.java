package ClienteMascota;

import java.util.ArrayList;

import java.util.Scanner;

public class ClienteMacota {

private static final String CobroCliente = null;
private static final String Datos = null;
private static final String Servicios = null;
private static final ArrayList<Mascota> Mascota = null;
static Scanner leer= new Scanner(System.in);
	public static void main(String[] args) {
		ArrayList<Cliente> DatosCliente =new ArrayList<>();
		Boolean salir=false;
		while(salir==false){
			System.out.println("---------Menu-------");
			System.out.println("1. Ingreso de datos del cliente");
			System.out.println("2. Ingreso de su mascota");
			System.out.println("3. Servicios");
			System.out.println("4. Impresion de datos");
			System.out.println("5. Cobro del cliente");
			System.out.println("6. Salir");
			
			int op=leer.nextInt();
			switch(op) {
			case 1:
				Cliente cliente1= ingresarCliente();
				Cliente.add(cliente1);
				break;
				
			case 2:
				IngresoDeSuMascota(Mascota);
				
				break;
				
			case 3:
				servicios(Servicios);
				break;
			case 4:
				impresionDatos(Datos);
				break;
			case 5:
				cobro(CobroCliente);
				break;
			case 6:
				salir=true;
				break;
			}					
		}
	}
	
		
		
	
	
	public static Cliente ingresarCliente() {
		System.out.println("Ingrese su cedula");
		String cedula = leer.next();
		System.out.println("Ingrese sus nombres");
		String nombres = leer.next();
		System.out.println("Ingrese sus apellidos ");
		String apellidos = leer.next();
		System.out.println("Ingrese su telefono");
		String telefono = leer.next();
		System.out.println("Ingrese su mes de nacimiento");
		int mes = leer.nextInt();
		Cliente cliente = new Cliente(cedula, nombres, apellidos, telefono, mes);
		return cliente;
	}
	private static void IngresoDeSuMascota(ArrayList<Mascota> listaMascota) {
		System.out.println("Fecha de ingreso");
		String fecha = leer.next();
		System.out.println("Raza");
		String raza =leer.next();
		System.out.println("Color"); 
		String color= leer.next();
	}
		
		private static void servicios(String servicios2) {
			
			System.out.println("Alojamiento del cliente con su mascota. presione 4 para continuar");
		}
		
		
		
		private static void impresionDatos(String datos2) {
			
			System.out.println("----------Datos del cliente-----------");
			
			System.out.println("cedula");
		
		
			System.out.println("Cliente:");
			
		
			
			System.out.println("Telefono:");
			
				
			
			System.out.println("Mes de nacimiento:");
			
			System.out.println("----------Datos de la mascota---------");
			System.out.println("Raza:");
			
			System.out.println("Color:");
			
			System.out.println("Tipo:");		}
		

		
		
		private static void cobro(String cobrocliente2) {
			System.out.println("Fecha de ingreso:");
			
			System.out.println("Valor por raza:");
			
			System.out.println("iva:");
			
			System.out.println("Total a pagar:");
			
			
			
			
	}

}
