package Formularios;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Numero_Letras extends JInternalFrame {
	private JTextField textField;
	private JLabel lbl_palabra;
	private JButton btn_calcular;
	private JLabel lbl_resultado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Numero_Letras frame = new Numero_Letras();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Numero_Letras() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		lbl_palabra = new JLabel("Ingrese una palabra");
		lbl_palabra.setBounds(10, 96, 108, 13);
		getContentPane().add(lbl_palabra);
		
		textField = new JTextField();
		textField.setBounds(156, 93, 96, 19);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		btn_calcular = new JButton("Calcular");
		btn_calcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String palabra = textField.getText();
				int numeroLetras = contarLetras(palabra);
				lbl_resultado.setText(String.valueOf(numeroLetras));
			}
		});
		btn_calcular.setBounds(294, 92, 85, 21);
		getContentPane().add(btn_calcular);
		
		lbl_resultado = new JLabel("...");
		lbl_resultado.setBounds(152, 190, 45, 13);
		getContentPane().add(lbl_resultado);

	}
	
	private int contarLetras(String palabra) {
        return palabra.length();
    }

	public AbstractButton getBtn_calcular() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getTextField() {
		// TODO Auto-generated method stub
		return null;
	}
}
