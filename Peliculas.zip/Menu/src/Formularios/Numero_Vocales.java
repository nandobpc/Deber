package Formularios;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Numero_Vocales extends JInternalFrame {
	private JTextField textField;
	private JLabel lbl_resultado;
	private JButton btn_calcular;
	private JLabel lbl_palabra;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Numero_Vocales frame = new Numero_Vocales();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Numero_Vocales() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		lbl_palabra = new JLabel("Ingrese una palabra");
		lbl_palabra.setBounds(10, 79, 109, 13);
		getContentPane().add(lbl_palabra);
		
		textField = new JTextField();
		textField.setBounds(140, 76, 96, 19);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		btn_calcular = new JButton("Calcular");
		btn_calcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String palabra = textField.getText();
				int numeroVocales = contarVocales(palabra);
				lbl_resultado.setText(String.valueOf(numeroVocales));
			}
		});
		btn_calcular.setBounds(265, 75, 85, 21);
		getContentPane().add(btn_calcular);
		
		lbl_resultado = new JLabel("...");
		lbl_resultado.setBounds(152, 187, 45, 13);
		getContentPane().add(lbl_resultado);

	}
	
	private int contarVocales(String palabra) {
        int contador = 0;
        String vocales = "aeiouAEIOU";
        for (int i = 0; i < palabra.length(); i++) {
            if (vocales.contains(String.valueOf(palabra.charAt(i)))) {
                contador++;
            }
        }
        return contador;
    }

	public AbstractButton getBtn_calcular() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getTextField() {
		// TODO Auto-generated method stub
		return null;
	}
}