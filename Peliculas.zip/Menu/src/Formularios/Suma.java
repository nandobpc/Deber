package Formularios;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Suma extends JInternalFrame {
    private JTextField txt_1;
    private JTextField txt_2;
    private JButton btn_calcular;
    private JLabel lbl_resultado;

    public Suma() {
        setTitle("Suma");
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Número 1:");
        lblNewLabel.setBounds(30, 43, 70, 14);
        getContentPane().add(lblNewLabel);

        txt_1 = new JTextField();
        txt_1.setBounds(110, 40, 86, 20);
        getContentPane().add(txt_1);
        txt_1.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Número 2:");
        lblNewLabel_1.setBounds(30, 94, 70, 14);
        getContentPane().add(lblNewLabel_1);

        txt_2 = new JTextField();
        txt_2.setBounds(110, 91, 86, 20);
        getContentPane().add(txt_2);
        txt_2.setColumns(10);

        btn_calcular = new JButton("Calcular");
        btn_calcular.setBounds(166, 148, 89, 23);
        getContentPane().add(btn_calcular);

        JLabel lblNewLabel_2 = new JLabel("Resultado:");
        lblNewLabel_2.setBounds(30, 203, 70, 14);
        getContentPane().add(lblNewLabel_2);

        lbl_resultado = new JLabel("");
        lbl_resultado.setBounds(110, 203, 86, 14);
        getContentPane().add(lbl_resultado);

    }

    public JTextField getTxt_1() {
        return txt_1;
    }

    public JTextField getTxt_2() {
        return txt_2;
    }

    public JButton getBtn_calcular() {
        return btn_calcular;
    }

    public JLabel getLbl_resultado() {
        return lbl_resultado;
    }
}