package Formularios;

import java.awt.EventQueue;

import javax.swing.AbstractButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;

public class Division extends JInternalFrame {
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Division frame = new Division();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Division() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Division");
		lblNewLabel.setBounds(64, 78, 77, 13);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Numero 1");
		lblNewLabel_1.setBounds(42, 147, 45, 13);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Numero 2");
		lblNewLabel_2.setBounds(42, 210, 45, 13);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("...");
		lblNewLabel_3.setBounds(224, 180, 45, 13);
		getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(99, 144, 96, 19);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(99, 207, 96, 19);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
	}

	public AbstractButton getLblNewLabel_5() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getTextField_1() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getBtn_calcular() {
		// TODO Auto-generated method stub
		return null;
	}
}