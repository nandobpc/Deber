package Formularios;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Par_Impar extends JInternalFrame {
	private JTextField textField;
	private JLabel lbl_resultado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Par_Impar frame = new Par_Impar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Par_Impar() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Escriba una palabra");
		lblNewLabel.setBounds(55, 85, 45, 13);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(148, 82, 96, 19);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Calcular");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String palabra = textField.getText();
				String resultado = verificarParImpar(palabra.length());
				lbl_resultado.setText(resultado);
			}
		});
		btnNewButton.setBounds(303, 81, 85, 21);
		getContentPane().add(btnNewButton);
		
		lbl_resultado = new JLabel("...");
		lbl_resultado.setBounds(178, 199, 45, 13);
		getContentPane().add(lbl_resultado);

	}
	
	private String verificarParImpar(int numero) {
        if (numero % 2 == 0) {
            return "El número es par";
        } else {
            return "El número es impar";
        }
    }

	public AbstractButton getBtnNewButton() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getTextField() {
		// TODO Auto-generated method stub
		return null;
	}

	public AbstractButton getLbl_resultado() {
		// TODO Auto-generated method stub
		return null;
	}
}