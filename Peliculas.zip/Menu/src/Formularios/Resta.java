package Formularios;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Resta extends JInternalFrame {
    private JTextField textField;
    private JTextField textField_1;
    private JButton btn_calcular;
    private JLabel lblNewLabel_1;

    public Resta() {
        setTitle("Resta");
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Número 1:");
        lblNewLabel.setBounds(31, 52, 70, 14);
        getContentPane().add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(111, 49, 86, 20);
        getContentPane().add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Número 2:");
        lblNewLabel_1.setBounds(31, 98, 70, 14);
        getContentPane().add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setBounds(111, 95, 86, 20);
        getContentPane().add(textField_1);
        textField_1.setColumns(10);

        btn_calcular = new JButton("Calcular");
        btn_calcular.setBounds(170, 150, 89, 23);
        getContentPane().add(btn_calcular);

        JLabel lblNewLabel_2 = new JLabel("Resultado:");
        lblNewLabel_2.setBounds(31, 204, 70, 14);
        getContentPane().add(lblNewLabel_2);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBounds(111, 204, 86, 14);
        getContentPane().add(lblNewLabel_1);

    }

    public JTextField getTextField() {
        return textField;
    }

    public JTextField getTextField_1() {
        return textField_1;
    }

    public JButton getBtn_calcular() {
        return btn_calcular;
    }

    public JLabel getLblNewLabel_1() {
        return lblNewLabel_1;
    }
}