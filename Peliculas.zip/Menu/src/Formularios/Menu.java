package Formularios;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Menu extends JFrame {

	private JPanel contentPane;
	private JDesktopPane escritorio;
	private JMenuItem Jmenuoperaciones;
	private JMenuItem JmenuCadenas;
	private JMenuItem JmenuParImpar;
	private JMenuItem JmenuRepeticionVocales;
	private JMenuItem JmenuNumeroLetras;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 986, 702);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu menuOperaciones = new JMenu("Operaciones");
		menuBar.add(menuOperaciones);

		Jmenuoperaciones = new JMenuItem("Suma");
		Jmenuoperaciones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Suma suma = new Suma();
				escritorio.add(suma);
				suma.setVisible(true);
				suma.getBtn_calcular().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int num1 = Integer.parseInt(suma.getTxt_1().getText());
						int num2 = Integer.parseInt(suma.getTxt_1().getText());
						int resultado = num1 + num2;
						suma.getLbl_resultado().setText(String.valueOf(resultado));
					}
				});
			}
		});
		menuOperaciones.add(Jmenuoperaciones);

		JMenuItem resta = new JMenuItem("Resta");
		resta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Resta resta = new Resta();
				escritorio.add(resta);
				resta.setVisible(true);
			}
		});
		menuOperaciones.add(resta);

		JMenuItem multiplicacion = new JMenuItem("Multiplicación");
		multiplicacion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Multiplicacion multiplicacion = new Multiplicacion();
				escritorio.add(multiplicacion);
				multiplicacion.setVisible(true);
			}
		});
		menuOperaciones.add(multiplicacion);

		JMenuItem division = new JMenuItem("División");
		division.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Division division = new Division();
				escritorio.add(division);
				division.setVisible(true);
			}
		});
		menuOperaciones.add(division);

		JMenu menuCadenas = new JMenu("Cadenas");
		menuBar.add(menuCadenas);

		JmenuCadenas = new JMenuItem("Número de Vocales");
		JmenuCadenas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Numero_Vocales numeroVocales = new Numero_Vocales();
				escritorio.add(numeroVocales);
				numeroVocales.setVisible(true);
				numeroVocales.getBtn_calcular().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String palabra = numeroVocales.getTextField().getText();
						int numeroVocales = contarVocales(palabra);
						//numeroVocales.getLabelResultado().setText(String.valueOf(numeroVocales));
					}
				});
			}
		});
		menuCadenas.add(JmenuCadenas);

		JmenuRepeticionVocales = new JMenuItem("Repetición de Vocales");
		JmenuRepeticionVocales.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Repeticion_Vocales repeticionVocales = new Repeticion_Vocales();
				escritorio.add(repeticionVocales);
				repeticionVocales.setVisible(true);
				repeticionVocales.getBtn_calcular().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String palabra = repeticionVocales.getTextField().getText();
						int repeticionVocales = contarRepeticionVocales(palabra);
						JMenuItem JmenuNumeroLetras = new JMenuItem("Número de Letras");
						JmenuNumeroLetras.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Numero_Letras numeroLetras = new Numero_Letras();
								escritorio.add(numeroLetras);
								numeroLetras.setVisible(true);
								numeroLetras.getBtn_calcular().addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										String palabra = numeroLetras.getTextField().getText();
										int numeroLetras = contarLetras(palabra);
										int resultadoNumeroLetras = contarLetras(palabra);
									//	numeroLetras.getLbl_resultado().setText(String.valueOf(resultadoNumeroLetras));
									}
								});
							}
						});
						menuCadenas.add(JmenuNumeroLetras);
					}
				});
			}
		});
		menuCadenas.add(JmenuNumeroLetras);

		JMenu menuParImpar = new JMenu("Par/Impar");
		menuBar.add(menuParImpar);

		JmenuParImpar = new JMenuItem("Verificar Par/Impar");
		JmenuParImpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Par_Impar parImpar = new Par_Impar();
				escritorio.add(parImpar);
				parImpar.setVisible(true);
				parImpar.getBtnNewButton().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String palabra = parImpar.getTextField().getText();
						String resultado = verificarParImpar(palabra.length());
						parImpar.getLbl_resultado().setText(resultado);
					}
				});
			}
		});
		menuParImpar.add(JmenuParImpar);

		escritorio = new JDesktopPane();
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(escritorio, BorderLayout.CENTER);
		setContentPane(contentPane);
	}

	private int contarVocales(String palabra) {
		int contador = 0;
		String vocales = "aeiouAEIOU";

		for (int i = 0; i < palabra.length(); i++) {
			if (vocales.contains(String.valueOf(palabra.charAt(i)))) {
				contador++;
			}
		}

		return contador;
	}

	private int contarRepeticionVocales(String palabra) {
		int contador = 0;
		String vocales = "aeiouAEIOU";

		for (int i = 0; i < palabra.length(); i++) {
			if (vocales.contains(String.valueOf(palabra.charAt(i)))) {
				contador++;
			}
		}

		return contador;
	}

	private int contarLetras(String palabra) {
		return palabra.length();
	}

	private String verificarParImpar(int numero) {
		if (numero % 2 == 0) {
			return "El número es par";
		} else {
			return "El número es impar";
		}
	}
}