
public class Main {

	public static void main(String[] args) {
		String nombre = "alfonso";
        int edad = 40;
        
        System.out.println("EL nombre ingresado es " + nombre + " y su edad ingresada es de " +edad);
	}

}
