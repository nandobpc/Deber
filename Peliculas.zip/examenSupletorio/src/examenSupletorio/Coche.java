package examenSupletorio;

public class Coche {

	String placa;
    String propietario;
    String marca;
    String color;
    float kilometraje;

    @Override
    public String toString() {
        return "Coche: [" + "placa=" + placa + ", propietario=" + propietario + ", marca=" + marca + ", color=" + color + ", kilometraje=" + kilometraje + ']';
    }

    
    public Coche() {
    }

    public Coche(String placa, String propietario, String marca, String color, float kilometraje) {
        this.placa = placa;
        this.propietario = propietario;
        this.marca = marca;
        this.color = color;
        this.kilometraje = kilometraje;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(float kilometraje) {
        this.kilometraje = kilometraje;
    }
    
    
}

