package examenSupletorio;


import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nando Pozo
 */
public class ExamenSupletorio {
    
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
        
        ArrayList <Coche> listaCoches= new ArrayList <>();
		boolean salir = false;
		
	while (salir==false){
            System.out.println("-----------Menu--------");
            System.out.println("1. Ingresar nuevo coche");
            System.out.println("2. Mostrar todos los coches");
            System.out.println("3. Mostrar los coches de una marca determinada");
            System.out.println("4. Mostrar los coches con menos de un numero determinado de kilometros");
            System.out.println("5. Mostrar los coches que no sean de un color determinado");
            System.out.println("6. Mostrar todos los coches comprendidos entre un rango superior e inferior de kilometros");
            System.out.println("7. Salir");
            int op=leer.nextInt();
                
            switch(op) {
                case 1:
                    Coche coche= nuevoCoche();
                    listaCoches.add(coche);
                    System.out.println("Coche guardado con exito");
                    break;
                case 2:
                    imprimirTodo(listaCoches); 
                    break;
                case 3:
                    imprimirMarca(listaCoches);
                    break;
                case 4:
                    imprimirMaxKm(listaCoches);
                    break;
                case 5: 
                    imprimirNoColor(listaCoches);
                    break;                    
                case 6:
                    imprimirRangoKm(listaCoches);
                    break;
                case 7:
                    salir=true; 
                    break;
                }
        }
    }

        public static Coche nuevoCoche() {
            System.out.println("Ingrese la placa");
            String placa = leer.next();
            System.out.println("Ingrese el nombre del propietario");
            String propietario = leer.next();
            System.out.println("Ingrese la marca");
            String marca = leer.next();
            System.out.println("Ingrese el color");
            String color = leer.next();
            System.out.println("Ingrese el kilometraje");
            float kilometraje= leer.nextFloat();

            Coche coche = new Coche (placa, propietario, marca, color, kilometraje);
            
            return coche;
            }

        
        public static void imprimirTodo(ArrayList <Coche>  listaCoches) {
            
            System.out.println("Resultado:");

            for (Coche cocheTurno: listaCoches) {

                System.out.println(cocheTurno); 

            }
        }
        
        public static void imprimirMarca(ArrayList <Coche>  listaCoches) {

            System.out.println("Ingrese la marca deseada");
            String marcaObjetivo = leer.next();
            
            System.out.println("Resultado:");

            for (Coche cocheTurno: listaCoches) {

                    if (cocheTurno.getMarca().equals(marcaObjetivo)) {
                        System.out.println(cocheTurno); 
                    }

            }
        }

        public static void imprimirMaxKm(ArrayList <Coche>  listaCoches) {

            System.out.println("Ingrese el maximo kilometraje");
            float maximo = leer.nextFloat();
            
            System.out.println("Resultado:");

            for (Coche cocheTurno: listaCoches) {

                    if (cocheTurno.getKilometraje()<maximo) {
                        System.out.println(cocheTurno); 
                    }

            }
        }
        
        public static void imprimirNoColor(ArrayList <Coche>  listaCoches) {

            System.out.println("Ingrese el color que no se desea que se imprima");
            String colorOjetivo = leer.next();
            
            System.out.println("Resultado:");

            for (Coche cocheTurno: listaCoches) {

                    if (!cocheTurno.getColor().equals(colorOjetivo)) {
                        System.out.println(cocheTurno); 
                    }
            }
        }

        
        public static void imprimirRangoKm(ArrayList <Coche>  listaCoches) {

            System.out.println("Ingrese el kilometraje minimo");
            float minimo = leer.nextFloat();
            System.out.println("Ingrese el kilometraje maximo");
            float maximo = leer.nextFloat();
            
            System.out.println("Resultado:");

            for (Coche cocheTurno: listaCoches) {

                    if ((cocheTurno.getKilometraje()>minimo) && (cocheTurno.getKilometraje()<maximo)) {
                            System.out.println(cocheTurno);
                    }

            }
	}
}

