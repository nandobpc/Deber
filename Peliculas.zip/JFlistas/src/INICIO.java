import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

public class INICIO extends JFrame {

    private JPanel contentPane;
    private JTextPane textPane;
    private JLabel lblNewLabel;
    private JTextField txt_inferior;
    private JLabel lblNewLabel_1;
    private JTextField txt_superior;
    private JButton btnMostrar;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    INICIO frame = new INICIO();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public INICIO() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        textPane = new JTextPane();
        textPane.setBounds(228, 10, 163, 243);
        contentPane.add(textPane);
        
        lblNewLabel = new JLabel("Limite inferior");
        lblNewLabel.setBounds(28, 73, 80, 13);
        contentPane.add(lblNewLabel);
        
        txt_inferior = new JTextField();
        txt_inferior.setBounds(118, 70, 96, 19);
        contentPane.add(txt_inferior);
        txt_inferior.setColumns(10);
        
        lblNewLabel_1 = new JLabel("Limite superior");
        lblNewLabel_1.setBounds(28, 123, 80, 31);
        contentPane.add(lblNewLabel_1);
        
        txt_superior = new JTextField();
        txt_superior.setBounds(118, 129, 96, 19);
        contentPane.add(txt_superior);
        txt_superior.setColumns(10);
        
        btnMostrar = new JButton("Mostrar");
        btnMostrar.setBounds(74, 191, 89, 23);
        contentPane.add(btnMostrar);

        btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarNumerosImpares();
            }
        });
    }

    private void mostrarNumerosImpares() {
        String inferiorText = txt_inferior.getText().trim();
        String superiorText = txt_superior.getText().trim();

        int inferior = Integer.parseInt(inferiorText);
        int superior = Integer.parseInt(superiorText);

        List<Integer> lista = new ArrayList<>();
        for (int i = inferior; i <= superior; i++) {
            if (i % 2 != 0) {
                lista.add(i);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int num : lista) {
            sb.append(num).append("\n");
        }
        textPane.setText(sb.toString());
    }
}