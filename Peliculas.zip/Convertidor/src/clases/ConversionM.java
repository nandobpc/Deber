package clases;

public class ConversionM {
    public double convertir(double valor, String unidadObjetivo) {
        double resultado = 0.0;

        switch (unidadObjetivo) {
            case "km":
                resultado = valor / 1000;
                break;
            case "cm":
                resultado = valor * 100;
                break;
            case "mm":
                resultado = valor * 1000;
                break;
            case "Mi":
                resultado = valor / 1609.34;
                break;
            
        }

        return resultado;
    }
}