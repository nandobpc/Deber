package clases;

public class ConversionKm {
    public double convertir(double valor, String unidadObjetivo) {
        if (unidadObjetivo.equals("m")) {
            return valor * 1000.0;
        } else if (unidadObjetivo.equals("cm")) {
            return valor * 100000.0;
        } else if (unidadObjetivo.equals("mm")) {
            return valor * 1000000.0;
        } else {
            return valor;
        }
    }
}