package clases;

public class ConversionMm {
    public double convertir(double valor, String unidadObjetivo) {
        if (unidadObjetivo.equals("cm")) {
            return valor / 10.0;
        } else if (unidadObjetivo.equals("km")) {
            return valor / 1000000.0;
        } else {
            return valor;
        }
    }
}