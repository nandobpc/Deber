package clases;

public class ConversionMi {
    public double convertir(double valor, String unidadObjetivo) {
        double resultado = 0.0;

        switch (unidadObjetivo) {
            case "km":
                resultado = valor * 1.60934;
                break;
            case "m":
                resultado = valor * 1609.34;
                break;
            case "cm":
                resultado = valor * 160934;
                break;
            case "mm":
                resultado = valor * 1.609e+6;
                break;
          
        }

        return resultado;
    }
}