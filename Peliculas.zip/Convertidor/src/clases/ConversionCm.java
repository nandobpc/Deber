package clases;

public class ConversionCm {
    public double convertir(double valor, String unidadObjetivo) {
        if (unidadObjetivo.equals("km")) {
            return valor / 100000.0;
        } else if (unidadObjetivo.equals("m")) {
            return valor / 100.0;
        } else if (unidadObjetivo.equals("mm")) {
            return valor * 10.0;
        } else {
            
            return valor;
        }
    }
}
