package formulario;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import clases.ConversionCm;
import clases.ConversionKm;
import clases.ConversionM;
import clases.ConversionMi;
import clases.ConversionMm;

import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.AbstractListModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Inicio extends JFrame {

    private JPanel contentPane;
    private JList<String> lista1;
    private JList<String> lista2;
    private JTextArea txt_valor;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Inicio frame = new Inicio();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Inicio() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 447, 354);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        lista1 = new JList<String>();
        lista1.setModel(new AbstractListModel<String>() {
            String[] values = new String[] {"Mi", "km", "m", "cm", "mm"};
            public int getSize() {
                return values.length;
            }
            public String getElementAt(int index) {
                return values[index];
            }
        });
        lista1.setBounds(20, 44, 139, 176);
        contentPane.add(lista1);
        
        lista2 = new JList<String>();
        lista2.setModel(new AbstractListModel<String>() {
            String[] values = new String[] {"Mi", "km", "m", "cm", "mm"};
            public int getSize() {
                return values.length;
            }
            public String getElementAt(int index) {
                return values[index];
            }
        });
        lista2.setBounds(262, 44, 139, 176);
        contentPane.add(lista2);
        
        JLabel lblNewLabel_1 = new JLabel("km");
        lblNewLabel_1.setBounds(56, 20, 45, 13);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("m");
        lblNewLabel_2.setBounds(278, 20, 45, 13);
        contentPane.add(lblNewLabel_2);
        
        txt_valor = new JTextArea();
        txt_valor.setBounds(133, 242, 139, 31);
        contentPane.add(txt_valor);
        
        JLabel lblNewLabel = new JLabel("...");
        lblNewLabel.setBounds(165, 271, 74, 36);
        contentPane.add(lblNewLabel);
        
        JButton btnConvertir = new JButton("Convertir");
        btnConvertir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String valor = txt_valor.getText();
                String unidadSeleccionada = lista1.getSelectedValue();
                String unidadObjetivo = lista2.getSelectedValue();
                
                
                double resultado = 0.0;

                if (unidadSeleccionada.equals("cm")) {
                    ConversionCm conversionCm = new ConversionCm();
                    resultado = conversionCm.convertir(Double.parseDouble(valor), unidadObjetivo);
                } else if (unidadSeleccionada.equals("km")) {
                    ConversionKm conversionKm = new ConversionKm();
                    resultado = conversionKm.convertir(Double.parseDouble(valor), unidadObjetivo);
                } else if (unidadSeleccionada.equals("mm")) {
                ConversionMm conversionMm = new ConversionMm();
                resultado = conversionMm.convertir(Double.parseDouble(valor), unidadObjetivo);
                } else if (unidadSeleccionada.equals("m")) {
                ConversionM conversionM = new ConversionM();
                resultado = conversionM.convertir(Double.parseDouble(valor), unidadObjetivo);
                } else if (unidadSeleccionada.equals("Mi")) {
                ConversionMi conversionMi = new ConversionMi();
                resultado = conversionMi.convertir(Double.parseDouble(valor), unidadObjetivo);
                }

                lblNewLabel.setText(String.valueOf(resultado));
                }
                });

                btnConvertir.setBounds(166, 211, 85, 21);
                contentPane.add(btnConvertir);
                }
}