
public class Main {

	public static void main(String[] args) {
		int a= 10;
		int b= 5;
		
		//indicador que que orden se realiza la operacion entre A y B 
		System.out.println("Operacion AB");
		
		//suma de A y B 
		System.out.println("El resultado de la suma de 10 + 5  es " + (a+b)  );
		
		
		//Resta de A menos B 
System.out.println("El resultado de la resta de 10 menos 5 es = " + (a-b));


//Multiplicacion de a y b 
System.out.println("El resultado de la multiplicacion entre 10 y 5 es =  "  + (a*b));

//division de A entre B 
System.out.println("El resultado de la division de 10 entre 5 es = " +( a / b));

//Separacion de menu ahora B y A 
System.out.println("----------------------------------------------------");
System.out.println("Operacion BA");

//Suma de B y A
System.out.println("El resultado de la suma de 5+10  es = " + (b+a)  );

//Resta de B y A 
System.out.println("El resultado de la resta de 5 menos 10 es = " + (b-a));

//Multiplicacion de B y A
System.out.println("El resultado de la multiplicacion entre 5 y 10 es =  "  + (b*a));

//Division de B y A
System.out.println("El resultado de la division de 5 entre 10 es = " +( b / a));


	}

}
