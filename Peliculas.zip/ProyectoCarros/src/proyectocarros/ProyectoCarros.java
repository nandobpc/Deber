/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */


package proyectocarros;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Nando Pozo
 */
public class ProyectoCarros {
    
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
        
        ArrayList <Carro> listaCarros= new ArrayList <>();
        
        Boolean salir=false;
        
        while (salir==false){
            System.out.println("-----------Menu--------");
            System.out.println("1. Ingreso de datos");
            System.out.println("2. Listar carros por color");
            System.out.println("3. Listar todos los carros");
            System.out.println("4. Salir");
            int op=leer.nextInt();
            
            switch(op) {
                case 1: 
                    Carro carro = guardarCarro();
                    listaCarros.add(carro);
                    break;
                
                case 2:
                    listarCarrosColor(listaCarros);
                    break;
            		
                case 3:
                    listarCarros(listaCarros);
                    break;
            		
                case 4:
                    salir=true;
                    break;
            }
        } 
    }
	
    public static Carro guardarCarro(){
        
        System.out.println("Ingrese el color");
        String color = leer.next();
        
        System.out.println("Ingrese la marca");
        String marca = leer.next();
        
        System.out.println("Ingrese el modelo");
        String modelo = leer.next();
        
        System.out.println("Ingrese el numero de asientos");
        int asientos = leer.nextInt();
        
        System.out.println("Ingrese la placa");
        String placa = leer.next();
        
        Carro carro= new Carro(color, marca, modelo, asientos, placa);
        
        return carro;

    }
    
    public static void listarCarrosColor (ArrayList <Carro> listaCarros) {
        System.out.println("Ingrese el color deseado");
        String color = leer.next();
        
        for (Carro c : listaCarros)
            if (c.getColor().equals(color)) {
                System.out.println(c);
            }
    }
    
    public static void listarCarros(ArrayList <Carro> listaCarros) {
        for (Carro c : listaCarros)
            System.out.println(c);
    }
}
