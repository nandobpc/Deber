/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectocarros;

/**
 *
 * @author Nando Pozo
 */
public class Carro {

    @Override
	public String toString() {
		return "Carro [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", asientos=" + asientos
				+ ", placa=" + placa + "]";
	}

	String color;
    String marca; 
    String modelo;
    int asientos; 
    String placa;

    public void setColor(String color) {
        this.color = color;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAsientos() {
        return asientos;
    }

    public String getPlaca() {
        return placa;
    }

    public Carro() {
    }

    public Carro(String color, String marca, String modelo, int asientos, String placa) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.asientos = asientos;
        this.placa = placa;
    }

}