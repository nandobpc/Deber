package PracticaR;

public class Empresa {
private String RazonS;
private float Ruc;
private String Repre;
private Direccion Dire;

public Empresa(String razonS, float ruc, String repre) {
	super();
	RazonS = razonS;
	Ruc = ruc;
	Repre = repre;
	
}
public String getRazonS() {
	return RazonS;
}
public void setRazonS(String razonS) {
	RazonS = razonS;
}
public float getRuc() {
	return Ruc;
}
public void setRuc(float ruc) {
	Ruc = ruc;
}
public String getRepre() {
	return Repre;
}
public void setRepre(String repre) {
	Repre = repre;
}
public String getDire() {
	String d;
	d="Calle: " + Dire.getCalle()+
			"Barrio: " + Dire.getBarrio() + 
			"Casa Nro: " + Dire.getCasaN();
	return d; 
}
public void setDire(Direccion dire) {
	Dire = dire;
}

}
