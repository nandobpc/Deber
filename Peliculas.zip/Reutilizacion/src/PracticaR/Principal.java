package PracticaR;

public class Principal {

	public static void main(String[] args) {

Direccion d1=new Direccion("Parque lineal", "Chichico", 9);
Direccion d2=new Direccion("Malecon tena", "atlanta" ,140);
Persona pe1=new Persona("Nando P",21,180,150);

pe1.setDire(d1);
System.out.println("Nombres:"+ pe1.getNombre());
System.out.println("Edad:"+ pe1.getEdad());
System.out.println("Estatura: "+ pe1.getEstatura());
System.out.println("Direcion: " + pe1.getDire());

Persona pe2=new Persona("Alex G",20,170,160);
pe2.setDire(d2);
System.out.println("Nombres:"+ pe2.getNombre());
System.out.println("Edad:"+ pe2.getEdad());
System.out.println("Estatura: "+ pe2.getEstatura());
System.out.println("Direcion: " + pe2.getDire());

Empresa e1=new Empresa("Ossass",1234321,pe1.getNombre());
e1.setDire(d1);
System.out.println("Razon social de la empresa: "+ e1.getRazonS());
System.out.println("Direccion empresa: " +e1.getDire());
	}

}
