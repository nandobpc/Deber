package PracticaR;

public class Direccion {
private String calle;
private String barrio;
private int casaN;
 

public Direccion(String c, String b, int n)
{
	super();
	this.calle=c;
	this.barrio=b;
	this.casaN=n;
	
}


public String getCalle() {
	return calle;
}


public void setCalle(String calle) {
	this.calle = calle;
}


public String getBarrio() {
	return barrio;
}


public void setBarrio(String barrio) {
	this.barrio = barrio;
}


public int getCasaN() {
	return casaN;
}


public void setCasaN(int casaN) {
	this.casaN = casaN;
}

}
