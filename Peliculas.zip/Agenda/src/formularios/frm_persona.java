package formularios;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class frm_persona extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JTextField txt_busqueda_cedula;
    private Connection connection;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
    private boolean casillasBloqueadas = true;
    private JTextField txt_busca_apellido;
    private JLabel lbl_busca_apellido;
    private JButton btn_busqueda_cedula;
    private JButton btnActualizar;
    private JButton btnGuardarCambios;
    private JButton btnNuevo;
    private JButton btnCancelar;
    private JButton btn_busqueda_apellido;
    private JButton btn_busqueda_apellido_2;
    private JButton btnNewButton;
    /**
     * Launch the application.
     */private void editarRegistro() {
    	    activarCasillas();
    	    btnActualizar.setEnabled(false);
    	    btnGuardarCambios.setEnabled(true);
    	    btnCancelar.setEnabled(true);
    	    casillasBloqueadas = false;
    	}
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frm_persona frame = new frm_persona(null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public frm_persona(Connection connection) {
        this.connection = connection;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 742, 481);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(317, 100, 359, 334);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        JLabel lblNewLabel = new JLabel("Busqueda cedula");
        lblNewLabel.setBounds(50, 86, 103, 13);
        contentPane.add(lblNewLabel);

        txt_busqueda_cedula = new JTextField();
        txt_busqueda_cedula.setBounds(148, 83, 96, 19);
        contentPane.add(txt_busqueda_cedula);
        txt_busqueda_cedula.setColumns(10);
        txt_busqueda_cedula.setEnabled(true);

        JLabel lblNewLabel_2 = new JLabel("Cedula");
        lblNewLabel_2.setBounds(33, 158, 56, 13);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("Nombre");
        lblNewLabel_3.setBounds(33, 209, 56, 13);
        contentPane.add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("Apellido");
        lblNewLabel_4.setBounds(33, 271, 56, 13);
        contentPane.add(lblNewLabel_4);

        JLabel lblNewLabel_5 = new JLabel("Direccion");
        lblNewLabel_5.setBounds(33, 315, 56, 13);
        contentPane.add(lblNewLabel_5);

        JLabel lblNewLabel_6 = new JLabel("Telefono");
        lblNewLabel_6.setBounds(33, 367, 56, 13);
        contentPane.add(lblNewLabel_6);

        textField_2 = new JTextField();
        textField_2.setBounds(121, 155, 146, 19);
        contentPane.add(textField_2);
        textField_2.setColumns(10);
        textField_2.setEnabled(false);

        textField_3 = new JTextField();
        textField_3.setBounds(121, 206, 146, 19);
        contentPane.add(textField_3);
        textField_3.setColumns(10);
        textField_3.setEnabled(false);

        textField_4 = new JTextField();
        textField_4.setBounds(121, 268, 146, 19);
        contentPane.add(textField_4);
        textField_4.setColumns(10);
        textField_4.setEnabled(false);

        textField_5 = new JTextField();
        textField_5.setBounds(121, 312, 146, 19);
        contentPane.add(textField_5);
        textField_5.setColumns(10);
        textField_5.setEnabled(false);

        textField_6 = new JTextField();
        textField_6.setBounds(121, 364, 146, 19);
        contentPane.add(textField_6);
        textField_6.setColumns(10);
        textField_6.setEnabled(false);

        btn_busqueda_apellido_2 = new JButton("Buscar por Apellido");
        btn_busqueda_apellido_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                buscarPorApellido();
            }
        });
        btn_busqueda_apellido_2.setBounds(40, 48, 213, 21);
        contentPane.add(btn_busqueda_apellido_2);

        lbl_busca_apellido = new JLabel("Busqueda Apellido");
        lbl_busca_apellido.setBounds(40, 22, 113, 13);
        contentPane.add(lbl_busca_apellido);

        txt_busca_apellido = new JTextField();
        txt_busca_apellido.setColumns(10);
        txt_busca_apellido.setBounds(148, 19, 96, 19);
        contentPane.add(txt_busca_apellido);

        btn_busqueda_cedula = new JButton("Buscar por Cedula");
        btn_busqueda_cedula.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                buscarPorCedula();
            }
        });
        btn_busqueda_cedula.setBounds(40, 112, 213, 21);
        contentPane.add(btn_busqueda_cedula);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarTabla();
            }
        });
        btnActualizar.setBounds(317, 38, 96, 21);
        contentPane.add(btnActualizar);

        btnGuardarCambios = new JButton("Guardar Cambios");
        btnGuardarCambios.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarCambios();
            }
        });
        btnGuardarCambios.setBounds(423, 38, 133, 21);
        contentPane.add(btnGuardarCambios);

        btnNuevo = new JButton("Nuevo");
        btnNuevo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nuevoRegistro();
            }
        });
        btnNuevo.setBounds(566, 38, 96, 21);
        contentPane.add(btnNuevo);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelar();
            }
        });
        btnCancelar.setBounds(566, 69, 96, 21);
        contentPane.add(btnCancelar);

        // Desactivar los botones de Guardar Cambios y Cancelar
        btnGuardarCambios.setEnabled(false);
        btnCancelar.setEnabled(false);
        
        btnNewButton = new JButton("Editar");
        btnNewButton.setBounds(447, 69, 85, 21);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editarRegistro();
            }
        });
        // Desactivar las casillas de texto
        desactivarCasillas();

        // Rellenar la tabla con los datos iniciales
        actualizarTabla();
    }

    // Método para buscar una persona por cédula
    private void buscarPorCedula() {
        String cedula = txt_busqueda_cedula.getText().trim();

        // Verificar si se ingresó una cédula válida
        if (cedula.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese una cédula");
            return;
        }

        try {
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM personas WHERE cedula = '" + cedula + "'";
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                // Mostrar los datos de la persona encontrada en las casillas de texto
                textField_2.setText(resultSet.getString("cedula"));
                textField_3.setText(resultSet.getString("nombre"));
                textField_4.setText(resultSet.getString("apellido"));
                textField_5.setText(resultSet.getString("direccion"));
                textField_6.setText(resultSet.getString("telefono"));
            } else {
                // Mostrar un mensaje si no se encontró ninguna persona con la cédula ingresada
                JOptionPane.showMessageDialog(this, "No se encontró ninguna persona con la cédula ingresada");
            }

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar personas por apellido
    private void buscarPorApellido() {
        String apellido = txt_busca_apellido.getText().trim();

        // Verificar si se ingresó un apellido válido
        if (apellido.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un apellido");
            return;
        }

        try {
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM personas WHERE apellido = '" + apellido + "'";
            ResultSet resultSet = statement.executeQuery(query);

            // Crear un modelo de tabla para mostrar los resultados
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.addColumn("Cedula");
            tableModel.addColumn("Nombre");
            tableModel.addColumn("Apellido");
            tableModel.addColumn("Direccion");
            tableModel.addColumn("Telefono");

            // Agregar las filas con los datos encontrados en la tabla
            while (resultSet.next()) {
                String cedula = resultSet.getString("cedula");
                String nombre = resultSet.getString("nombre");
                String apellidoResult = resultSet.getString("apellido");
                String direccion = resultSet.getString("direccion");
                String telefono = resultSet.getString("telefono");
                Object[] row = { cedula, nombre, apellidoResult, direccion, telefono };
                tableModel.addRow(row);
            }

            table.setModel(tableModel);

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar la tabla con todos los registros
    private void actualizarTabla() {
        try {
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM personas";
            ResultSet resultSet = statement.executeQuery(query);

            // Crear un modelo de tabla para mostrar los resultados
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.addColumn("Cedula");
            tableModel.addColumn("Nombre");
            tableModel.addColumn("Apellido");
            tableModel.addColumn("Direccion");
            tableModel.addColumn("Telefono");

            // Agregar las filas con los datos encontrados en la tabla
            while (resultSet.next()) {
                String cedula = resultSet.getString("cedula");
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                String direccion = resultSet.getString("direccion");
                String telefono = resultSet.getString("telefono");
                Object[] row = { cedula, nombre, apellido, direccion, telefono };
                tableModel.addRow(row);
            }

            table.setModel(tableModel);

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para guardar los cambios realizados en los datos de una persona
    private void guardarCambios() {
        String cedula = textField_2.getText().trim();
        String nombre = textField_3.getText().trim();
        String apellido = textField_4.getText().trim();
        String direccion = textField_5.getText().trim();
        String telefono = textField_6.getText().trim();

        // Verificar si se ingresaron datos válidos
        if (cedula.isEmpty() || nombre.isEmpty() || apellido.isEmpty() || direccion.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese todos los datos");
            return;
        }

        try {
            Statement statement = connection.createStatement();
            String query = "UPDATE personas SET nombre = '" + nombre + "', apellido = '" + apellido
                    + "', direccion = '" + direccion + "', telefono = '" + telefono + "' WHERE cedula = '" + cedula
                    + "'";
            int rowsAffected = statement.executeUpdate(query);

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Los cambios se guardaron correctamente");
                desactivarCasillas();
                btnActualizar.setEnabled(true);
                btnGuardarCambios.setEnabled(false);
                btnCancelar.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar los cambios");
            }

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para crear un nuevo registro
    private void nuevoRegistro() {
        limpiarCasillas();
        activarCasillas();
        btnActualizar.setEnabled(false);
        btnGuardarCambios.setEnabled(true);
        btnCancelar.setEnabled(true);
        casillasBloqueadas = false;
    }

    // Método para cancelar la creación o edición de un registro
    private void cancelar() {
        limpiarCasillas();
        desactivarCasillas();
        btnActualizar.setEnabled(true);
        btnGuardarCambios.setEnabled(false);
        btnCancelar.setEnabled(false);
        casillasBloqueadas = true;
    }

    // Método para limpiar todas las casillas de texto
    private void limpiarCasillas() {
        txt_busqueda_cedula.setText("");
        textField_2.setText("");
        textField_3.setText("");
        textField_4.setText("");
        textField_5.setText("");
        textField_6.setText("");
        txt_busca_apellido.setText("");
    }

    // Método para activar todas las casillas de texto
    private void activarCasillas() {
        txt_busqueda_cedula.setEnabled(true);
        textField_2.setEnabled(true);
        textField_3.setEnabled(true);
        textField_4.setEnabled(true);
        textField_5.setEnabled(true);
        textField_6.setEnabled(true);
        txt_busca_apellido.setEnabled(true);
        lbl_busca_apellido.setEnabled(true);
        btn_busqueda_cedula.setEnabled(true);
        btn_busqueda_apellido_2.setEnabled(true);
    }

    // Método para desactivar todas las casillas de texto
    private void desactivarCasillas() {
        txt_busqueda_cedula.setEnabled(false);
        textField_2.setEnabled(false);
        textField_3.setEnabled(false);
        textField_4.setEnabled(false);
        textField_5.setEnabled(false);
        textField_6.setEnabled(false);
        txt_busca_apellido.setEnabled(false);
        lbl_busca_apellido.setEnabled(false);    
        btn_busqueda_cedula.setEnabled(false);
        btn_busqueda_apellido_2.setEnabled(false);
    }
}