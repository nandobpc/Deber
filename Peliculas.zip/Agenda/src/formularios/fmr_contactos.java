package formularios;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class fmr_contactos extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;
    private JTextField textField_1;
    private JButton btnNewButton;
    private JLabel lblNewLabel_1;
    private JButton btnNewButton_1;
    private JButton btnNewButton_2;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    fmr_contactos frame = new fmr_contactos();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public fmr_contactos() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 796, 471);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        textField = new JTextField();
        textField.setBounds(156, 74, 180, 19);
        contentPane.add(textField);
        textField.setColumns(10);

        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("codigo");
        tableModel.addColumn("nombre");
        tableModel.addColumn("teléfono");
        tableModel.addColumn("mail");
        tableModel.addColumn("cod persona");
        tableModel.addColumn("sentencia");
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 158, 760, 266);
        contentPane.add(scrollPane);

        JLabel lblNewLabel = new JLabel("Telefono");
        lblNewLabel.setBounds(89, 35, 45, 13);
        contentPane.add(lblNewLabel);

        textField_1 = new JTextField();
        textField_1.setBounds(156, 32, 252, 19);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        btnNewButton = new JButton("Consultar");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textField.setEnabled(true);
                textField_1.setEnabled(true);
            }
        });
        btnNewButton.setBounds(466, 64, 85, 21);
        contentPane.add(btnNewButton);

        textField.setEnabled(false);
        textField_1.setEnabled(false);

        lblNewLabel_1 = new JLabel("E mail");
        lblNewLabel_1.setBounds(89, 77, 45, 13);
        contentPane.add(lblNewLabel_1);

        btnNewButton_1 = new JButton("Cancelar");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textField.setEnabled(false);
                textField_1.setEnabled(false);
            }
        });
        btnNewButton_1.setBounds(581, 64, 85, 21);
        contentPane.add(btnNewButton_1);

        btnNewButton_2 = new JButton("Mostrar");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String telefono = textField.getText();
                filtrarPersonasPorTelefono(telefono);
            }
        });
        btnNewButton_2.setBounds(687, 64, 85, 21);
        contentPane.add(btnNewButton_2);
    }

    private void filtrarPersonasPorTelefono(String telefono) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0); 
        
        Object[] rowData = { "1", "Nando", 1983148193, "nandobpc43@gmail.com", "456", "Sentencia1" };
        tableModel.addRow(rowData);
    }
}