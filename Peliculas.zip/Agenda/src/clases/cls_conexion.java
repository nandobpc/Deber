package clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class cls_conexion {
    private String databaseName;
    private String username;
    private String password;
    private Connection connection;

    public cls_conexion(String databaseName, String username, String password) {
        this.databaseName = databaseName;
        this.username = username;
        this.password = password;
        this.connection = null;
    }

    public void connect() {
        try {
            connection = DriverManager.getConnection(databaseName, username, password);
            System.out.println("Conexion establecida a la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }

    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión cerrada.");
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        } else {
            System.out.println("No hay conexión activa.");
        }
    }

    public Connection getConnection() {
        return connection;
    }

  
    public static void main(String[] args) {
       
        cls_conexion conexion = new cls_conexion("jdbc:mysql://localhost/ba_poo2", "Nando", "12345678");
        conexion.connect();

        conexion.disconnect();
    }
}