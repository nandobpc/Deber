package clases;

public class cls_contacto {
    private int codigo;
    private String nombre;
    private String telefono;
    private String mail;
    private int cod_persona;
    private String sentencia;

    public cls_contacto(int codigo, String nombre, String telefono, String mail, int cod_persona, String sentencia) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.telefono = telefono;
        this.mail = mail;
        this.cod_persona = cod_persona;
        this.sentencia = sentencia;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public int getCod_persona() {
        return cod_persona;
    }

    public void setCod_persona(int cod_persona) {
        this.cod_persona = cod_persona;
    }

    public String getSentencia() {
        return sentencia;
    }

    public void setSentencia(String sentencia) {
        this.sentencia = sentencia;
    }
}