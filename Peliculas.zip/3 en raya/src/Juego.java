import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Juego extends JFrame {

	private JPanel contentPane;
	private JButton[][] buttons;
	private char currentPlayer;
	private boolean gameEnded;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Juego frame = new Juego();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Juego() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(3, 3));
		buttons = new JButton[3][3];
		currentPlayer = 'X';
		gameEnded = false;

		initializeButtons();
	}

	private void initializeButtons() {
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				JButton button = new JButton();
				buttons[row][col] = button;
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (((JButton) e.getSource()).getText().equals("") && !gameEnded) {
							button.setText(Character.toString(currentPlayer));
							button.setEnabled(false);
							gameEnded = checkGameEnd();

							if (!gameEnded) {
								changePlayer();
								makeMove();
								gameEnded = checkGameEnd();
							}
						}
					}
				});
				contentPane.add(button);
			}
		}
	}

	private boolean checkGameEnd() {
		for (int i = 0; i < 3; i++) {
			if (buttons[i][0].getText().equals(buttons[i][1].getText())
					&& buttons[i][1].getText().equals(buttons[i][2].getText())
					&& !buttons[i][0].getText().equals("")) {
				showMessage(buttons[i][0].getText() + " ganó!");
				disableButtons();
				return true;
			}

			if (buttons[0][i].getText().equals(buttons[1][i].getText())
					&& buttons[1][i].getText().equals(buttons[2][i].getText())
					&& !buttons[0][i].getText().equals("")) {
				showMessage(buttons[0][i].getText() + " ganó!");
				disableButtons();
				return true;
			}
		}

		if (buttons[0][0].getText().equals(buttons[1][1].getText())
				&& buttons[1][1].getText().equals(buttons[2][2].getText())
				&& !buttons[0][0].getText().equals("")) {
			showMessage(buttons[0][0].getText() + " ganó!");
			disableButtons();
			return true;
		}

		if (buttons[0][2].getText().equals(buttons[1][1].getText())
				&& buttons[1][1].getText().equals(buttons[2][0].getText())
				&& !buttons[0][2].getText().equals("")) {
			showMessage(buttons[0][2].getText() + " ganó!");
			disableButtons();
			return true;
		}

		if (isBoardFull()) {
			showMessage("¡Empate!");
			disableButtons();
			return true;
		}

		return false;
	}

	private void changePlayer() {
		if (currentPlayer == 'X') {
			currentPlayer = 'O';
		} else {
			currentPlayer = 'X';
		}
	}

	private void makeMove() {
		int[] move = getRandomMove();
		if (move != null) {
			buttons[move[0]][move[1]].setText(Character.toString(currentPlayer));
			buttons[move[0]][move[1]].setEnabled(false);
		}
	}

	private int[] getRandomMove() {
		int emptyCount = 0;
		int[][] emptyCells = new int[9][2];

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				if (buttons[row][col].getText().equals("")) {
					emptyCells[emptyCount][0] = row;
					emptyCells[emptyCount][1] = col;
					emptyCount++;
				}
			}
		}

		if (emptyCount == 0) {
			return null;
		}

		int randomIndex = (int) (Math.random() * emptyCount);
		return emptyCells[randomIndex];
	}

	private boolean isBoardFull() {
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				if (buttons[row][col].getText().equals("")) {
					return false;
				}
			}
		}
		return true;
	}

	private void showMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}

	private void disableButtons() {
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				buttons[row][col].setEnabled(false);
			}
		}
	}
}