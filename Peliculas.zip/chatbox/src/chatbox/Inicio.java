package chatbox;

import java.awt.EventQueue;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Inicio extends JFrame {
    private JPanel contentPane;
    private JCheckBox chk_papas;
    private JCheckBox chk_queso;
    private JButton btn_verificar;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Inicio frame = new Inicio();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Inicio() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 568, 405);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        btn_verificar = new JButton("verificar");
        btn_verificar.setBounds(245, 137, 85, 21);
        btn_verificar.addActionListener(e -> verificarSeleccion());
        contentPane.add(btn_verificar);

        chk_papas = new JCheckBox("Extra papas");
        chk_papas.setBounds(54, 99, 93, 21);
        contentPane.add(chk_papas);

        chk_queso = new JCheckBox("Extra queso");
        chk_queso.setBounds(54, 154, 93, 21);
        contentPane.add(chk_queso);
    }

    private void verificarSeleccion() {
        boolean seleccionPapas = chk_papas.isSelected();
        boolean seleccionQueso = chk_queso.isSelected();

        if (seleccionPapas && seleccionQueso) {
            JOptionPane.showMessageDialog(null, "Has seleccionado papas y queso");
        } else if (seleccionPapas) {
            JOptionPane.showMessageDialog(null, "Has seleccionado papas");
        } else if (seleccionQueso) {
            JOptionPane.showMessageDialog(null, "Has seleccionado queso");
        } else {
            JOptionPane.showMessageDialog(null, "No has seleccionado ninguna opción");
        }
    }
}