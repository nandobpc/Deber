
package Clases;
 import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


public class registro {
    String ID_personas;
     String Nombre;
     String Grado;
     String Codigo;
     String sentencia;
 Conexion conex = new Conexion();  
 Login log = new Login(); 
public registro(){
    this.ID_personas="";
    this.Nombre="";
    this.Grado="";
    this.Codigo="";
    this.sentencia="";
    
}    

    public String getID_personas() {
        return ID_personas;
    }

    public void setID_persona(String ID_persona) {
        this.ID_personas = ID_persona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getGrado() {
        return Grado;
    }

    public void setGrado(String Grado) {
        this.Grado = Grado;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getSentencia() {
        return sentencia;
    }

    public void setSentencia(String sentencia) {
        this.sentencia = sentencia;
    }

    public Conexion getConex() {
        return conex;
    }

    public void setConex(Conexion conex) {
        this.conex = conex;
    }
public boolean instertar(){
    int respuesta=0;
    try{
            String sentencia ="INSERT INTO registros(ID,Nombre,Grado,Codigo)values(?,?,?,?)";
            PreparedStatement st = conex.conectar().prepareStatement(sentencia);
            st.setString(1, this.getID_personas());
            st.setString(2, this.getNombre());
            st.setString(3, this.getGrado());
            st.setString(4, this.getCodigo());
            respuesta = st.executeUpdate();
            
            
    } catch(Exception e){
        JOptionPane.showMessageDialog(null, e);
        
    } if(respuesta>0){
        return true;
    }else{
        return false;
        
    }
    
}
public Object[][] consultas(){
    Object objs[][]=null;
 try{
     this.sentencia ="Select * from registros";
     Statement st = conex.conectar().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
     ResultSet datos = st.executeQuery(this.sentencia);
     datos.last();
     int nf = datos.getRow();
     objs = new Object[nf][4];
     int f=0;
     datos.beforeFirst();
     while(datos.next())
     {
         objs[f][0]=datos.getObject(1);
         objs[f][1]=datos.getObject(2);
         objs[f][2]=datos.getObject(3);
         objs[f][3]=datos.getObject(4);
      f++;   
     }   
     
     
 }   catch(Exception e){
     
 }   return objs;
}
}
