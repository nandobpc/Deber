
package Clases;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
public class Login {
    String ID_persona;
    String Nombre;
    String Apellido;
    String Grado;
    String Codigo;
    String sentencia;
Conexion conex = new Conexion();
public Login(){
    this.ID_persona="";
    this.Nombre="";
    this.Apellido="";
    this.Grado="";
    this.Codigo="";
    this.sentencia="";
    
}

    public String getID_persona() {
        return ID_persona;
    }

    public void setID_persona(String ID_persona) {
        this.ID_persona = ID_persona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getGrado() {
        return Grado;
    }

    public void setGrado(String Grado) {
        this.Grado = Grado;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getSentencia() {
        return sentencia;
    }

    public void setSentencia(String sentencia) {
        this.sentencia = sentencia;
    }

    public Conexion getConex() {
        return conex;
    }

    public void setConex(Conexion conex) {
        this.conex = conex;
    }
    public boolean insertar(){
        int respuesta=0;
      try{
          String sentencia ="INSERT INTO login(ID,Nombre,Apellido,Grado,Codigo)values(?,?,?,?,?)";
          PreparedStatement st = conex.conectar().prepareStatement(sentencia);
           
          st.setString(1, this.getID_persona());
          st.setString(2, this.getNombre());
          st.setString(3, this.getApellido());
          st.setString(4, this.getGrado());
          st.setString(5, this.getCodigo());
            respuesta = st.executeUpdate();
      }  catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
      } if(respuesta>0){
          return true;
      }else{
          return false;
      }
    }
    public Object[][]consultar(){
        Object obj [][]=null;
        try{
             this.sentencia ="Select * from login ";
             Statement st = conex.conectar().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
             ResultSet datos = st.executeQuery(this.sentencia);
             datos.last();
             int nf = datos.getRow();
             obj = new Object[nf][5];
             int f=0;
             datos.beforeFirst();
             
                while(datos.next()){
                    obj[f][0]=datos.getObject(1);
                    obj[f][1]=datos.getObject(2);
                    obj[f][2]=datos.getObject(3);
                    obj[f][3]=datos.getObject(4);
                    obj[f][4]=datos.getObject(5);
             f++;       
                    
      }
             
        } catch(Exception e){
            
        } return obj;
    } 
}
