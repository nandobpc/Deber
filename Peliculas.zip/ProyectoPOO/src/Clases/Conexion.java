
package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexion {
    static String db ="inicio_db";
    static String ussuary ="root";
    static String password="";
    static String url="jdbc:mysql://localhost/" +db;
   
      Connection conexion = null;
      {
          try{ Class.forName("com.mysql.cj.jdbc.Driver");
          conexion = DriverManager.getConnection(url,ussuary,password);
            if(conexion!=null){
                JOptionPane.showMessageDialog(null, "Conexion con Exito");
                }else{
                 JOptionPane.showMessageDialog(null, "Error de Conexion");
            }
              
          } catch(Exception e){
              JOptionPane.showMessageDialog(null, e);
          }
      }
      public Connection conectar(){
          return conexion;
      }
}
