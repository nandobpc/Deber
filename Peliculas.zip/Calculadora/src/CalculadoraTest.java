import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculadoraTest {

	void testSuma(){
		Calculadora calcu = new Calculadora(20, 10);
		int resultado = calcu.suma();
		assertEquals(30,resultado);
		}

		void testResta(){
		Calculadora calcu = new Calculadora(20, 10);
		int resultado = calcu.resta();
		assertEquals(10,resultado);
		}

		void testMultiplica(){
		Calculadora calcu = new Calculadora(20, 10);
		int resultado = calcu.multiplica();
		assertEquals(200,resultado);
		}

		void testDivide(){
		Calculadora calcu = new Calculadora(20, 10);
		int resultado = calcu.divide();
		assertEquals(2,resultado);
		}
}