

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author Byron Pozo
 * 
 */
public class ExamenRemedial {
    
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
        boolean salir = false;
        ArrayList <Persona> personas = new ArrayList <>();
        
        while (salir==false){
            System.out.println("OPCIONES");
            System.out.println("1. Aniadir nueva persona");
            System.out.println("2. Mostrar todas las personas");
            System.out.println("3. Mostras segun signo del zodiaco");
            System.out.println("4. Pasar nombres y apellidos de mayores de edad a un vector e imprimir");
            System.out.println("5. Pasar numeros de cedula de mayores de edad a un HashMap e imprimir");
            System.out.println("6. Salir");
            int op=leer.nextInt();
            
            switch(op) {
                case 1:
                    Persona nuevaPersona= crearPersona();
                    personas.add(nuevaPersona);
                    break; 
                case 2:
                    mostrarPersonas(personas); 
                    break;  
                case 3:
                    mostrarSegunSigno(personas);
                    break;
                case 4:
                    crearVectorNombresPorEdad(personas);
                    break;
                case 5: 
                    crearHashmapCedulaMayores(personas);
                    break;               
                case 6:
                    salir=true; 
                    break;
                }
        }
    }
    
    public static Persona crearPersona() {
        System.out.println("Ingrese la cedula");
        String cedula = leer.next();
        System.out.println("Ingrese el nombre");
        String nombre = leer.next();
        System.out.println("Ingrese el apellido");
        String apellido = leer.next();
        System.out.println("Ingrese el anio de nacimeinto");
        int anioNacimiento = leer.nextInt();
        // La edad se calcula restando 2023 y el año de nacimiento
        int edad = 2023 - anioNacimiento;
        System.out.println("Ingrese el signo del zodiaco");
        String signoZodiaco = leer.next();

        // Llama al contructor pasandole los datos de la nueva persona
        Persona persona = new Persona (cedula, nombre, apellido, anioNacimiento, signoZodiaco, edad);
Persona nando = new Persona () ;
        return persona;
    }
    
    
    public static void mostrarPersonas(ArrayList <Persona>  personas) {

        for (Persona personaI: personas) {

            System.out.println(personaI); 

        }
    }
    
    public static void mostrarSegunSigno(ArrayList <Persona> personas) {
          
        //Pedir el signo por teclado
        System.out.println("Ingrese el signo del zodiaco");
        String signoZodiaco = leer.next();
          
        // Recorre el ArrayList de personas, imprimiendo las que tengan el mismo signo que el ingresado
            for (Persona personaI: personas) {
                if (personaI.getSignoZodiaco().equals(signoZodiaco)) {
                    System.out.println(personaI); 
                }
            }
        }
    
    public static void crearVectorNombresPorEdad(ArrayList <Persona>  listaPersonas) {
		
        //Solo mayores de edad
        int edadMinima = 18;
        
        int contadorPersonas =0;

        // Calcula el tamaño que tendrá el vector (cuantas personas son mayores de edad)
        for (Persona personaTurno: listaPersonas) {
                if (personaTurno.getEdad()>=edadMinima) {
                    contadorPersonas++;
                }
        }
        
        // Define el vector de tipo String para el nombre y apellido
        String vectorNombres[] = new String[contadorPersonas+1];
        
        // Recorre el arraylist de personas y si una es mayor de edad entonces pasa su nombre y apellido al vector
        int contadorVector=0;
        for (int i =0; i<listaPersonas.size(); i++) {
            Persona personaTurno = listaPersonas.get(i);
            if (personaTurno.getEdad()>=edadMinima) {
                vectorNombres[contadorVector] = personaTurno.getNombre() + " " + personaTurno.getApellido();
                contadorVector++;
            }
        }
        
        
        // vectorNombres es el vector creado
        
        System.out.println("Resultado: ");
        for (int i=0; i<vectorNombres.length-1; i++) {
            System.out.println(vectorNombres[i]);
        }
    }
    
    public static void crearHashmapCedulaMayores(ArrayList <Persona>  listaPersonas) {

        // Crear un hashmap llamado hashmapCedulas, con el numero de cedula y la edad de cada persona
        HashMap<String, Integer> hashmapCedulas = new HashMap<>();

        // Recorre el ArrayList de personas y pasa la cedula de las mayores de edad al Hashmap
        for (Persona personaTurno: listaPersonas) {
                if (personaTurno.getEdad()>=18) {
                    hashmapCedulas.put(personaTurno.getCedula(), personaTurno.getEdad());
                }
        }
        
        // Imprimir resultados
        
        System.out.println("Resultado: ");
        System.out.println("Formato: Cedula=Edad");
        System.out.println(hashmapCedulas);
        
		
	}
}
