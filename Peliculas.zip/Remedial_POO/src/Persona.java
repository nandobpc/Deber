
/**
 *
 * @author Byron Pozo
 */
public class Persona {    
    String cedula;
    String nombre;
    String apellido;
    int anioNacimiento;
    String signoZodiaco;
    int edad;

    @Override
    public String toString() {
        return "Persona [" + "cedula=" + cedula + ", nombre=" + nombre + ", apellido=" + apellido + ", anioNacimiento=" + anioNacimiento + ", signoZodiaco=" + signoZodiaco + ", edad=" + edad + ']';
    }

    

    public Persona() {
    	this.cedula="";
    	this.nombre = "";
        this.apellido = "";
        this.anioNacimiento = 0;
        this.signoZodiaco = "";
        this.edad = 0;
    }
    //el constructor nos permite instanciar un objeto
    
    public Persona(String cedula) { 
    	this.cedula= cedula;
    	this.nombre = "";
        this.apellido = "";
        this.anioNacimiento = 0;
        this.signoZodiaco = "";
        this.edad = 0;
    }
    public Persona(String cedula, String nombre, String apellido, int anioNacimiento, String signoZodiaco, int edad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.anioNacimiento = anioNacimiento;
        this.signoZodiaco = signoZodiaco;
        this.edad = edad;
    }

    
    
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    public void setAnioNacimiento(int anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
    }

    public String getSignoZodiaco() {
        return signoZodiaco;
    }

    public void setSignoZodiaco(String signoZodiaco) {
        this.signoZodiaco = signoZodiaco;
    }
    
    
    
}
