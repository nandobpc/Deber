package Variables;

public class Main {

	public static void main(String[] args) {
		int ñiñi= 7;
		char ñiñi2= 'c';
System.out.println("La variable ñiñi contiene el número:" +ñiñi);
System.out.println("La variable ñiñi2 contiene la letra:" +ñiñi2);
	}

}
