import java.util.ArrayList;
import java.util.Scanner;

import Clases.clase_persona;
import Clases.contacto_persona;

public class Inicio {

 static Scanner leer = new Scanner(System.in);
 public static void main(String[] args) {
	 ArrayList <contacto_persona> contacto = new ArrayList <contacto_persona>();
	 ArrayList <clase_persona> personas = new ArrayList <clase_persona>();

 Boolean salir=false;

 while (salir==false){
 System.out.println("-----------Menu--------");
 System.out.println("1. Ingreso de datos del cliente");
 System.out.println("2. ingreso de mascota");
 System.out.println("3. servicios ");
 System.out.println("4. impresion de datos ");
 System.out.println("5. cobro del cliente ");
 System.out.println("6. Salir");
 int op=leer.nextInt();

 switch(op) {
 case 1:
  clase_persona persona = guardarPersona();
 personas.add(persona);
 
 break;

 case 2:
	 listarCedulaPersonas (personas);
 break;

 case 3:
 listarContactos (personas);
 break;

 
 case 6:
 salir=true;
 break;
 }
 }
 }
 private static void listarContactos(ArrayList<Clases.clase_persona> personas) {
	
	
}
private static void clase_persona(ArrayList<clase_persona> personas) {
	
	
}
public static clase_persona guardarPersona(){

 System.out.println("Ingrese su nombre");
 String nombre = leer.next();

 System.out.println("Ingrese su apellido");
 String apellido = leer.next();

 System.out.println("Ingrese su correo");
 String correo = leer.next();

 System.out.println("Ingrese su cedula");
 int cedula = leer.nextInt();


 clase_persona personas= new clase_persona(nombre, apellido, correo, cedula);

 return personas;
 }

 public static void listarCedulaPersonas (ArrayList <clase_persona> personas) {
 System.out.println("Ingrese su cedula ");
 String cedula = leer.next();

 for (clase_persona p : personas)
if (p.getcedula().equals(cedula))
 System.out.println(p);
 }
 

 public static void listarpersonas(ArrayList <clase_persona> Listapersonas) {
 for (clase_persona p : Listapersonas)
 System.out.println(p);
 

 }
}