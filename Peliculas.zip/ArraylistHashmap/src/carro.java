import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class carro {

	public static void main(String[] args) {
		Scanner leer= new Scanner(System.in);
		ArrayList <String> c= new ArrayList();
		for (int j=0;j<4;j++)
		{
			System.out.println("Ingrese una palabra");
		c.add(leer.nextLine());
		}
		Iterator <String> ver= c.iterator();
		while(ver.hasNext())
		{
		System.out.println(ver.next());
		}
		
			System.out.println("--------------");
		for (int f=0;f<c.size();f++)
	
		{
		System.out.println(c.get(f)); 
	}
		}
	}	
	
