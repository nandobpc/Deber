
public class Operacion {

}
