import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InsumosFrame extends JFrame {
    private JButton botonConsultar;
    private JButton botonAgregar;
    private JButton botonEliminar;

    public InsumosFrame() {
        initUI();
    }

    private void initUI() {
        setTitle("Gestión de Insumos");
        setSize(300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(null);

        botonConsultar = new JButton("Consultar Insumos");
        botonConsultar.setBounds(80, 30, 140, 25);
        add(botonConsultar);

        botonConsultar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                consultarInsumos();
            }
        });

        botonAgregar = new JButton("Agregar Insumo");
        botonAgregar.setBounds(80, 70, 140, 25);
        add(botonAgregar);

        botonAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarInsumo();
            }
        });

        botonEliminar = new JButton("Eliminar Insumo");
        botonEliminar.setBounds(80, 110, 140, 25);
        add(botonEliminar);

        botonEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarInsumo();
            }
        });
    }

    private void consultarInsumos() {
        // Agrega aquí la lógica para consultar los insumos en la base de datos
    }

    private void agregarInsumo() {
        // Agrega aquí la lógica para agregar un insumo a la base de datos
    }

    private void eliminarInsumo() {
        // Agrega aquí la lógica para eliminar un insumo de la base de datos
    }

    public static void main(String[] args) {
        InsumosFrame insumosFrame = new InsumosFrame();
        insumosFrame.setVisible(true);
    }
}
