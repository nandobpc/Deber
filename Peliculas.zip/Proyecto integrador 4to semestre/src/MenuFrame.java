import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class MenuFrame extends JFrame {
    public MenuFrame() {
        initUI();
    }

    private void initUI() {
        setTitle("Menú Principal");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu opcionesMenu = new JMenu("Opciones");
        menuBar.add(opcionesMenu);

        JMenuItem usuarioItem = new JMenuItem("Usuario");
        opcionesMenu.add(usuarioItem);

        JMenuItem insumosItem = new JMenuItem("Insumos");
        opcionesMenu.add(insumosItem);

        JMenu acercaDeMenu = new JMenu("Acerca de");
        menuBar.add(acercaDeMenu);

        getContentPane().setLayout(null);
    }

    public static void main(String[] args) {
        MenuFrame menuFrame = new MenuFrame();
        menuFrame.setVisible(true);
    }
}
