import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField usuarioField;
    private JPasswordField contrasenaField;
    private JButton botonIngresar;

    public LoginFrame() {
        initUI();
    }

    private void initUI() {
        setTitle("Inicio de Sesión");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioLabel.setBounds(20, 30, 80, 25);
        panel.add(usuarioLabel);

        usuarioField = new JTextField();
        usuarioField.setBounds(100, 30, 160, 25);
        panel.add(usuarioField);

        JLabel contrasenaLabel = new JLabel("Contraseña:");
        contrasenaLabel.setBounds(20, 70, 80, 25);
        panel.add(contrasenaLabel);

        contrasenaField = new JPasswordField();
        contrasenaField.setBounds(100, 70, 160, 25);
        panel.add(contrasenaField);

        botonIngresar = new JButton("Ingresar");
        botonIngresar.setBounds(100, 120, 100, 25);
        panel.add(botonIngresar);

        botonIngresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Agrega aquí la lógica para verificar las credenciales
                // y abrir la siguiente ventana si las credenciales son correctas
            }
        });

        getContentPane().add(panel);
    }

    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }
}
