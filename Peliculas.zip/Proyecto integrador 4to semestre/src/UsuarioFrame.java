import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UsuarioFrame extends JFrame {
    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField edadField;
    private JTextField cedulaField;
    private JButton botonGuardar;

    public UsuarioFrame() {
        initUI();
    }

    private void initUI() {
        setTitle("Gestión de Usuarios");
        setSize(300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(null);

        JLabel nombreLabel = new JLabel("Nombre:");
        nombreLabel.setBounds(20, 30, 60, 25);
        add(nombreLabel);

        nombreField = new JTextField();
        nombreField.setBounds(100, 30, 160, 25);
        add(nombreField);

        JLabel apellidoLabel = new JLabel("Apellido:");
        apellidoLabel.setBounds(20, 70, 60, 25);
        add(apellidoLabel);

        apellidoField = new JTextField();
        apellidoField.setBounds(100, 70, 160, 25);
        add(apellidoField);

        JLabel edadLabel = new JLabel("Edad:");
        edadLabel.setBounds(20, 110, 60, 25);
        add(edadLabel);

        edadField = new JTextField();
        edadField.setBounds(100, 110, 60, 25);
        add(edadField);

        JLabel cedulaLabel = new JLabel("Cédula:");
        cedulaLabel.setBounds(20, 150, 60, 25);
        add(cedulaLabel);

        cedulaField = new JTextField();
        cedulaField.setBounds(100, 150, 160, 25);
        add(cedulaField);

        botonGuardar = new JButton("Guardar");
        botonGuardar.setBounds(100, 190, 100, 25);
        add(botonGuardar);

        botonGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarUsuario();
            }
        });
    }

    private void guardarUsuario() {
        String nombre = nombreField.getText();
        String apellido = apellidoField.getText();
        int edad = Integer.parseInt(edadField.getText());
        String cedula = cedulaField.getText();

        // Aquí deberías realizar la lógica para guardar el usuario en la base de datos

        JOptionPane.showMessageDialog(this, "Usuario guardado exitosamente", "Información", JOptionPane.INFORMATION_MESSAGE);
        limpiarCampos();
    }

    private void limpiarCampos() {
        nombreField.setText("");
        apellidoField.setText("");
        edadField.setText("");
        cedulaField.setText("");
    }

    public static void main(String[] args) {
        UsuarioFrame usuarioFrame = new UsuarioFrame();
        usuarioFrame.setVisible(true);
    }
}
