package formulario;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;

import clases.cls_persona;

public class frm_persona extends JFrame {

    private JPanel contentPane;
    private JTextField txt_cedula;
    private JTextField txt_nombre;
    private JTextField txt_apellido;
    private JTextField txt_nacimiento;
    private JLabel lblNewLabel_3;

    ArrayList<cls_persona> personas = new ArrayList<cls_persona>(); // ArrayList para almacenar objetos cls_persona
    private JButton btn_guardar;
    private JButton btn_verPersonas; // Botón para ver las personas guardadas
    private JTextPane textPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frm_persona frame = new frm_persona();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public frm_persona() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 555, 356);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Cedula");
        lblNewLabel.setBounds(61, 55, 45, 13);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Nombre");
        lblNewLabel_1.setBounds(61, 84, 45, 13);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("Apellido");
        lblNewLabel_2.setBounds(61, 125, 45, 13);
        contentPane.add(lblNewLabel_2);
        
        txt_cedula = new JTextField();
        txt_cedula.setBounds(116, 52, 96, 19);
        contentPane.add(txt_cedula);
        txt_cedula.setColumns(10);
        
        txt_nombre = new JTextField();
        txt_nombre.setBounds(116, 81, 96, 19);
        contentPane.add(txt_nombre);
        txt_nombre.setColumns(10);
        
        txt_apellido = new JTextField();
        txt_apellido.setBounds(116, 122, 96, 19);
        contentPane.add(txt_apellido);
        txt_apellido.setColumns(10);
        
        btn_guardar = new JButton("Guardar");
        btn_guardar.setBounds(201, 219, 85, 21);
        btn_guardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Obtener los valores ingresados en los campos de texto
                String cedula = txt_cedula.getText();
                String nombre = txt_nombre.getText();
                String apellido = txt_apellido.getText();
                String fecha = txt_nacimiento.getText();
                
                // Crear un objeto cls_persona con los valores ingresados
                cls_persona persona = new cls_persona(cedula, nombre, apellido, fecha);
                
                // Agregar la persona al ArrayList
                personas.add(persona);
                
                // Limpiar los campos de texto
                txt_cedula.setText("");
                txt_nombre.setText("");
                txt_apellido.setText("");
                txt_nacimiento.setText("");
            }
        });
        contentPane.add(btn_guardar);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(301, 63, 164, 151);
        contentPane.add(scrollPane);
        
        textPane = new JTextPane();
        scrollPane.setViewportView(textPane);
        
        lblNewLabel_3 = new JLabel("Fecha de nacimiento");
        lblNewLabel_3.setBounds(10, 171, 120, 13);
        contentPane.add(lblNewLabel_3);
        
        txt_nacimiento = new JTextField();
        txt_nacimiento.setBounds(140, 168, 96, 19);
        contentPane.add(txt_nacimiento);
        txt_nacimiento.setColumns(10);
        
        btn_verPersonas = new JButton("Ver Personas");
        btn_verPersonas.setBounds(313, 219, 120, 21);
        btn_verPersonas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarPersonas();
            }
        });
        contentPane.add(btn_verPersonas);
    }
    
    public void mostrarPersonas() {
        textPane.setText(""); // Limpiar el JTextPane antes de mostrar las personas
        
        // Iterar sobre el ArrayList de personas utilizando un Iterator
        Iterator<cls_persona> iterator = personas.iterator();
        while (iterator.hasNext()) {
            cls_persona persona = iterator.next();
            // Agregar la información de la persona al JTextPane
            textPane.setText(textPane.getText() + "Cedula: " + persona.getCedula() + "\n");
            textPane.setText(textPane.getText() + "Nombre: " + persona.getNombre() + "\n");
            textPane.setText(textPane.getText() + "Apellido: " + persona.getApellido() + "\n");
            textPane.setText(textPane.getText() + "Fecha de nacimiento: " + persona.getFecha() + "\n");
            textPane.setText(textPane.getText() + "\n");
        }
    }
}